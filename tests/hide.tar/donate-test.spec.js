const {test} = require('../fixtures');
const {expect} = require("@playwright/test");
//import { test, expect } from '@playwright/test';

test('Donate button test', async ({ page }) => {

    // Assert that the page title is correct
    expect(await page.title()).toBe('LitterPic');

    // look for Donate Button
    const buttonDonate = await page.$('Donate');
    expect(button).not.toBeNull();

    await button.click();
//    await page.waitForSelector('div.result');
//    const resultElement = await page.$('div.result');
//    expect(resultElement).not.toBeNull();
//    expect(await resultElement.isVisible()).toBeTruthy();
//    expect(await resultElement.innerText()).toContain('Button clicked successfully');

});
